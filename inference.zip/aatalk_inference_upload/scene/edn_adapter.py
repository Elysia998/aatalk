import torch
import torch.nn as nn


class EDNMoveAdapter(nn.Module):
    # Safe EDN v3: mouth expression residual adapter.
    #
    # This is a conservative approximation of the EDN idea:
    #     E_prime = E + Delta_E
    #
    # In InsTaG, E is approximated by the low-dimensional mouth-control feature
    # `move`. EDN predicts a small residual Delta_E from:
    #     move, audio feature, learnable source token, learnable emotion token.
    #
    # The residual is bounded and gated to avoid degrading the original model.

    def __init__(
        self,
        move_dim=None,
        audio_dim=32,
        emotion_dim=16,
        source_dim=16,
        hidden_dim=32,
        out_dim=None,
        gate_init=-5.0,
        max_delta=0.02,
        in_dim=None,
        init_bias=0.0,
    ):
        super().__init__()

        if move_dim is None:
            move_dim = in_dim if in_dim is not None else 3
        if out_dim is None:
            out_dim = move_dim

        self.move_dim = int(move_dim)
        self.audio_dim = int(audio_dim)
        self.emotion_dim = int(emotion_dim)
        self.source_dim = int(source_dim)
        self.out_dim = int(out_dim)
        self.max_delta = float(max_delta)

        # Learnable global tokens approximate source identity features and
        # emotion guidance when explicit labels are unavailable.
        self.source_token = nn.Parameter(torch.zeros(1, self.source_dim))
        self.emotion_token = nn.Parameter(torch.zeros(1, self.emotion_dim))
        self.gate_logit = nn.Parameter(torch.tensor(float(gate_init)))

        in_features = self.move_dim + self.audio_dim + self.source_dim + self.emotion_dim

        self.net = nn.Sequential(
            nn.Linear(in_features, int(hidden_dim)),
            nn.LayerNorm(int(hidden_dim)),
            nn.LeakyReLU(0.02, inplace=True),
            nn.Linear(int(hidden_dim), int(hidden_dim)),
            nn.LayerNorm(int(hidden_dim)),
            nn.LeakyReLU(0.02, inplace=True),
            nn.Linear(int(hidden_dim), self.out_dim),
        )

        # Start close to the original model.
        nn.init.zeros_(self.net[-1].weight)
        nn.init.constant_(self.net[-1].bias, float(init_bias))

    def forward(self, move_feat, audio_feat=None):
        if move_feat.dim() == 1:
            move_feat = move_feat.unsqueeze(0)

        b = move_feat.shape[0]
        device = move_feat.device
        dtype = move_feat.dtype

        if audio_feat is None:
            audio_feat = torch.zeros(b, self.audio_dim, device=device, dtype=dtype)
        else:
            if audio_feat.dim() == 1:
                audio_feat = audio_feat.unsqueeze(0)
            audio_feat = audio_feat.to(device=device, dtype=dtype)
            if audio_feat.shape[0] != b:
                audio_feat = audio_feat.expand(b, -1)

        src = self.source_token.to(device=device, dtype=dtype).expand(b, -1)
        emo = self.emotion_token.to(device=device, dtype=dtype).expand(b, -1)

        z = torch.cat([move_feat, audio_feat, src, emo], dim=-1)

        delta = self.max_delta * torch.tanh(self.net(z))
        gate = torch.sigmoid(self.gate_logit)

        return move_feat + gate * delta

    def delta_only(self, move_feat, audio_feat=None):
        refined = self.forward(move_feat, audio_feat)
        if move_feat.dim() == 1:
            move_feat = move_feat.unsqueeze(0)
        return refined - move_feat

    def gate_value(self):
        with torch.no_grad():
            return torch.sigmoid(self.gate_logit).item()

